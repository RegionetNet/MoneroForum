<?php
/**
 * Created by PhpStorm.
 * User: Eddie
 * Date: 10/04/15
 * Time: 16:30
 */

return [
	'expire' => '+ 1 day', //not used in receiving funds.
	'wallet'     => '10.0.2.2:18083', //address of the wallet daemon.
	'address'         => '9uHFSz45ef6Tqx1qqzygyMUhBKL5NaeJsQ2C9qot3TmMg96VSMcEMSu2Kna84kgRmabY4JesLweiWfuPD21sNe8q7wdtGRw', //Monero address to receive/send payments from.
	'alias'        => 'getmonero.org' // wallet alias.
];