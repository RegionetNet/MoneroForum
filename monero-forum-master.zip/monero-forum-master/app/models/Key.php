<?php

class Key extends \Eloquent {
	protected $fillable = [
		'key_id',
		'message',
		'password'
	];
}