<?php
 
use Zizaco\Entrust\EntrustPermission;
 
class Permission extends EntrustPermission {}