<?php

return [
	'path'  => '../workbench/eddieh/kramdown/bin/'
];