<pre>
{{{ $message }}}
</pre>