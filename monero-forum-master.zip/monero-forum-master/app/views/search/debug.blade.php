@extends('master')
@section('content')
	<pre>{{ var_dump($results) }}</pre>
	<hr>
@stop