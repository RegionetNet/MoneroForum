<p>Hello, friend of Monero,</p>
<p>You have a new private message on the Monero Forum!</p>
<p><a href="{{ URL::route('messages.conversation', [$pm->conversation_id]) }}">Click here to read and reply to this message</a>.</p>
<p>Regards,</p>
<p>The Monero Project Team</p>
