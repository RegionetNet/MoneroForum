<div class="panel panel-default queued-post">
	<div class="panel-body">
		{{ $queued_item->body }}
	</div>
</div>